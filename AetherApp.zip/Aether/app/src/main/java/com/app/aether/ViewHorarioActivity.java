package com.app.aether;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnFailureListener;
import com.google.firebase.database.ChildEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.List;

public class ViewHorarioActivity extends AppCompatActivity {

    RecyclerView recyclerView;
    DatabaseReference database;
    HorarioAdapter myAdapter;
    ArrayList<Horario> list;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_view_horario);

        recyclerView = findViewById(R.id.horariosList);
        database = FirebaseDatabase.getInstance().getReference("PrivateHorario");
        recyclerView.setHasFixedSize(true);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        list = new ArrayList<>();
        myAdapter = new HorarioAdapter(this,list);
        recyclerView.setAdapter(myAdapter);

        database.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {

                for (DataSnapshot dataSnapshot : snapshot.getChildren()){

                    Horario horario = dataSnapshot.getValue(Horario.class);
                    list.add(horario);
                }
                myAdapter.notifyDataSetChanged();
            }
            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                if (error.getCode() == DatabaseError.PERMISSION_DENIED) {
                    Toast.makeText(ViewHorarioActivity.this, "No tienes permiso para acceder a los datos", Toast.LENGTH_SHORT).show();
                } else if (error.getCode() == DatabaseError.NETWORK_ERROR) {
                    Toast.makeText(ViewHorarioActivity.this, "Error de red, por favor, comprueba tu conexión", Toast.LENGTH_SHORT).show();
                } else {
                    Toast.makeText(ViewHorarioActivity.this, "Se produjo un error al acceder a los datos", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }
}