package com.app.aether;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import com.google.firebase.auth.FirebaseAuth;

public class LobbyActivityModel extends AppCompatActivity {

    Button btn_logout, btn_addE, btn_view;
    FirebaseAuth mAuth;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_lobby);

        btn_logout = findViewById(R.id.btn_logout);
        btn_addE = findViewById(R.id.btn_addE);
        btn_view = findViewById(R.id.btn_view);

        mAuth = FirebaseAuth.getInstance();

        btn_logout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mAuth.signOut();
                finish();
                startActivity(new Intent(LobbyActivityModel.this, MainActivity.class));
            }
        });

        btn_addE.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(LobbyActivityModel.this, NameActivity.class));
            }
        });

        btn_view.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(LobbyActivityModel.this, ViewHorarioActivity.class));
            }
        });
    }
}