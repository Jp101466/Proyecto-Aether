package com.app.aether;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class HorarioAdapter extends RecyclerView.Adapter<HorarioAdapter.HorarioViewHolder> {
    private Context context;
    private List<Horario> horariosList;

    public HorarioAdapter(Context context, List<Horario> horariosList) {
        this.context = context;
        this.horariosList = horariosList;
    }

    @NonNull
    @Override
    public HorarioViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.item, parent, false);
        return new HorarioViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull HorarioViewHolder holder, int position) {
        Horario horario = horariosList.get(position);

        holder.fechaInicioTextView.setText(horario.getFechaInicio());
        holder.fechaFinTextView.setText(horario.getFechaFin());
        holder.horaInicioTextView.setText(horario.getHoraInicio());
        holder.horaFinTextView.setText(horario.getHoraFin());
        holder.nombreElecTextView.setText(horario.getNombreElec());
    }

    @Override
    public int getItemCount() {
        return horariosList.size();
    }

    public class HorarioViewHolder extends RecyclerView.ViewHolder {
        TextView fechaInicioTextView;
        TextView fechaFinTextView;
        TextView horaInicioTextView;
        TextView horaFinTextView;
        TextView nombreElecTextView;

        public HorarioViewHolder(View itemView) {
            super(itemView);
            fechaInicioTextView = itemView.findViewById(R.id.txt_fechaInicio);
            fechaFinTextView = itemView.findViewById(R.id.txt_fechaFin);
            horaInicioTextView = itemView.findViewById(R.id.txt_horaInicio);
            horaFinTextView = itemView.findViewById(R.id.txt_horaFin);
            nombreElecTextView = itemView.findViewById(R.id.txt_nombreElec);
        }
    }
}

